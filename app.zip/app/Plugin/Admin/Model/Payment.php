<?php
class Payment extends AppModel
{
    public $name = 'Payment';
    public $useTable = 'paypal_configs';
    public $primaryKey = 'id';
}
?>