<?php
class Subject extends AppModel
{
  public $actsAs = array('search-master.Searchable');
  public $Hasmany="questions";
  public $filterArgs = array('keyword' => array('type' => 'like','field'=>'Subject.subject_name'));
}
?>