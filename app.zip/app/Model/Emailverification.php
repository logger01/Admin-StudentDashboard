<?php
class Emailverification extends AppModel
{
  public $useTable="students";  
}
?>