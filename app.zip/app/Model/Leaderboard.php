<?php
class Leaderboard extends AppModel
{
  public $useTable="exam_results";  
}
?>