<?php
class Help extends AppModel
{
  public $useTable="helpcontents";
}
?>